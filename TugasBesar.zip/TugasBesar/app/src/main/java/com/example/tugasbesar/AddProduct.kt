package com.example.tugasbesar

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class AddProduct : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_product)
    }
}
