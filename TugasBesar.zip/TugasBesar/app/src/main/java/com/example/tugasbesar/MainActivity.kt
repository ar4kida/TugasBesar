package com.example.tugasbesar

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnAdd = findViewById(R.id.btnAdd) as ImageView
        btnAdd?.setOnClickListener {
            // your code to perform when the user clicks on the ImageView
            val intent = Intent(this, AddProduct::class.java)
            startActivity(intent)
        }
    }


}
